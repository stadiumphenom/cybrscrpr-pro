
# Deploying to Streamlit Cloud

1. Push this repo to your GitHub.
2. Go to https://streamlit.io/cloud
3. Connect your GitHub and choose this repo.
4. Set the following secrets:
   - `OPENAI_API_KEY`: Your OpenAI API Key
5. Deploy!

App will launch at something like:
https://<your-app-name>.streamlit.app
